"""Aurora core domain package."""
