# DECISIONS.md 追加：M2-002设计候选

## ADR-018：HTML使用Beautiful Soup与lxml

- 状态：Proposed
- 决定：解析静态HTML，不引入浏览器运行时。

## ADR-019：显式单URL使用HTTPX同步客户端

- 状态：Proposed
- 决定：只支持用户显式提交的单一HTTP(S) URL，不批量爬取。

## ADR-020：URL默认阻止私有网络

- 状态：Proposed
- 决定：DNS和redirect均复检，防止SSRF。

## ADR-021：PDF使用pdfplumber

- 状态：Proposed
- 决定：支持机器生成PDF的文本、布局和best-effort表格，不做OCR。

## ADR-022：字幕使用webvtt-py

- 状态：Proposed
- 决定：支持VTT和SRT，一Cue一ContentUnit。

## ADR-023：解析依赖使用可选Extra

- 状态：Proposed
- 决定：基础对象层不强依赖多载体解析库。

## ADR-024：限制PDF页数和输入资源

- 状态：Proposed
- 决定：HTML 10MiB、PDF 50MiB/500页、Transcript 10MiB，可配置覆盖。

## ADR-025：M2-002不修改SourceLocator

- 状态：Proposed
- 决定：使用现有页码、DOM和时间字段；PDF bbox延期。
