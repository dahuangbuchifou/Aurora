# M2-001 交付包应用说明

## 1. 建议分支

```bash
git checkout main
git pull
git checkout -b feature/m2-001-offline-ingestion
```

## 2. 校验交付包

在解压目录执行：

```bash
sha256sum -c SHA256SUMS.txt
```

全部文件必须显示 `OK`。

## 3. 完整复制

不要手工挑选文件。执行：

```bash
cp -a Aurora_M2-001_交付_V1.0/. /path/to/Aurora/
```

然后进入仓库：

```bash
cd /path/to/Aurora
git status --short
```

## 4. 安装与验证

```bash
source .venv/bin/activate
pip install -e ".[dev]"
alembic upgrade head
pytest --collect-only -q
pytest -q
pytest --cov=aurora --cov-branch --cov-report=term-missing --cov-fail-under=90
```

## 5. Schema

```bash
aurora-export-ingestion-schemas --output schemas/ingestion/v1
```

## 6. 不应出现的变化

```text
新的Alembic Revision
第18类核心对象
schemas/v1变化
schemas/v1_1变化
核心对象字段删除或重命名
```
