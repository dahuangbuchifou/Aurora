# Aurora M2-001 示例

这是一个 Markdown 段落。

- 支持确定性分段
- 支持幂等导入

> Claim 仍然不是 Fact。
