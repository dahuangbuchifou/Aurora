# M2-001 示例

在执行前先运行：

```bash
alembic upgrade head
```

Markdown：

```bash
aurora-ingest file examples/m2_001/example.md \
  --source-name "Aurora Example" \
  --source-type local_file \
  --source-key aurora-example
```

纯文本：

```bash
aurora-ingest file examples/m2_001/example.txt \
  --source-name "Aurora Example" \
  --source-type local_file \
  --source-key aurora-example
```

Structured Segments：

```bash
aurora-ingest segments examples/m2_001/structured_segments.json --output json
```
