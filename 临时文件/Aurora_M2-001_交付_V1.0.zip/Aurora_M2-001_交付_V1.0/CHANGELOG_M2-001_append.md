# CHANGELOG.md 追加：M2-001

## [0.4.0] - 2026-07-12

### Added

- 本地Markdown、纯文本和Structured Segments JSON导入。
- 确定性Markdown和纯文本分段。
- Source canonical identity与Document idempotency。
- `reuse/reject/new_version`重复策略。
- 确定性Source、Document、ContentUnit ID。
- ProcessingRun状态工作流与失败审计。
- `aurora-ingest` CLI和text/json输出。
- 默认10 MiB文件限制。
- 应用层Ingestion JSON Schema与示例。

### Changed

- ObjectRepository增加通用external_id和顶层payload字段查询。
- 项目版本更新至0.4.0。

### Verified

- M1全量回归继续通过。
- 本地测试129 passed，覆盖率96%。
- 三类M1-002测试材料完成离线E2E导入。
