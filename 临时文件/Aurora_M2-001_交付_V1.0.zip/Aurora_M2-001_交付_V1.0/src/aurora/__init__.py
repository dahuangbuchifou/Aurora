"""Aurora Intelligence Platform."""

__version__ = "0.4.0"
