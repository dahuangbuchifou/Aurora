# DECISIONS.md 追加：M2-001

## ADR-018：Source身份与Document内容身份分离

- 状态：Accepted
- Source：`workspace_id + source_type + canonical_source_key`。
- Document：`source_id + content_hash + parser_name + parser_version`。
- 原因：同一发布者的不同文档不得产生多个Source。

## ADR-019：M2-001采用确定性本地Parser

- 状态：Accepted
- 支持 Markdown、纯文本、Structured Segments JSON。
- Parser不访问数据库，不调用网络和LLM。
- 同一输入和Parser版本必须产生相同分段。

## ADR-020：Document与ContentUnit原子提交

- 状态：Accepted
- Document和全部ContentUnit使用同一业务事务。
- ProcessingRun使用独立事务保存失败审计。

## ADR-021：默认重复策略为reuse

- 状态：Accepted
- 重复输入复用Document与ContentUnit，但每次保留新的ProcessingRun。
- `reject`和`new_version`必须显式选择。

## ADR-022：应用层Ingestion DTO不进入核心对象模型

- 状态：Accepted
- IngestionRequest、IngestionResult和StructuredSegmentsManifest属于应用契约。
- Aurora V1.1的17类核心对象保持冻结。
