# M2-001 交付基线

本交付是相对于以下基线的增量包：

```text
Git Tag: v0.3.0-m1
Project Version: 0.3.0
Aurora Core Schema: V1.1 FROZEN
Alembic Head: 20260712_0002
M1 Test Baseline: 84 passed
```

应用前必须确认：

```bash
git status
git describe --tags --always
alembic current
pytest -q
```

本交付：

- 不修改17类核心对象语义；
- 不修改 `schemas/v1/`；
- 不修改 `schemas/v1_1/`；
- 不新增 Alembic Revision；
- 只增加 M2-001 应用层输入、Parser、Workflow、CLI和测试。
