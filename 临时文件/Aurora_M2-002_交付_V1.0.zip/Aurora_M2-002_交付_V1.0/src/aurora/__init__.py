"""Aurora Intelligence Platform."""

__version__ = "0.5.0"
