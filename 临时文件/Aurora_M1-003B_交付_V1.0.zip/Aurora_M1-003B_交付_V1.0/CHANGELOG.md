# Changelog

## [0.3.0] - 2026-07-12

### Added
- Aurora Schema V1.1 与 V1.0/V1.1 双版本读取
- DataPoint `MeasurementContext`，支持币种、数量级、报告标准、归属和合并范围
- Claim `ClaimDimension`，含竞争格局 `competition` 维度
- Provenance `DerivationLink` 与结构化派生关系
- Evidence 独立证据聚合与计数接口
- Claim 原子性警告式 Linter
- EvidenceRole 同范围直接性判定规则
- V1.1 JSON Schema、顶层多版本 Registry 与示例
- Payload dry-run、备份、迁移和恢复命令
- Alembic `schema_version` 索引迁移
- Repository 原始记录审计与按 Schema 版本查询

### Changed
- 新建对象默认写入 Schema V1.1
- V1.0 对象读取时在内存中保守适配，不自动写回
- SQLite Engine 支持可配置 timeout 与 `PRAGMA busy_timeout`
- Traceability 优先使用结构化派生关系

### Fixed
- 非依赖 `processing_run_id` 缺失不再计入阻塞性 dangling reference
- 同源 Evidence 在独立证据统计中不重复计数

### Verified
- M1-001 与 M1-002 回归测试全部通过
- 本地工程测试 84 passed，覆盖率 96%
- V1.0 案例可无损读取为 V1.1 当前模型
- Alembic upgrade/downgrade 与 Payload backup/restore 通过

## [0.2.0] - 2026-07-12

### Added
- 120 个对象的真实案例验证（3 案例 × 17 类型全覆盖）
- 参考图验证与来源回溯引擎（Traceability Engine）
- 任意对象到 Source 的完整路径追踪
- Evidence 独立分组与同源去重
- 认知链回溯：Fact → Knowledge → Insight → Opinion → Output
- 观点污染防护测试（claim_not_promoted_to_fact）
- jsonschema 开发依赖

### Verified
- 数据冲突处理（利用率 70% vs 76.5% → disputed）
- 管理层增长展望 vs UP主估值谨慎 → QUALIFY 而非 REFUTE
- PersonalOpinion 从未自动激活
- 单表 JSON 持久化在真实案例中工作正常

## [0.1.0] - 2026-07-12

### Added
- Aurora V1.0 十七类核心对象模型
- JSON Schema 导出与对象注册表
- SQLAlchemy 单表 JSON 持久化
- Alembic 初始迁移
- ObjectRepository、软删除和乐观版本控制
- 核心模型与数据库集成测试

### Fixed
- Alembic 运行时自动解析 `src/` 包路径
- Migration 测试隔离 `AURORA_DATABASE_URL` 环境变量

## [Unreleased]

### Added
- 初始化 Aurora GitHub 项目骨架。
