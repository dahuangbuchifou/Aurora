# CHANGELOG.md 追加：M1 Exit

## [0.3.0] - 2026-07-12

### Added

- Aurora V1.1 MeasurementContext。
- ClaimDimension，包括competition维度。
- DerivationLink结构化派生关系。
- V1.0/V1.1双版本读取和混合存储。
- Payload dry-run、备份、迁移和restore CLI。
- Evidence独立组聚合。
- Claim原子性Linter。
- EvidenceRole同范围判定规则。
- SQLite timeout和busy_timeout。
- V1.1 JSON Schema与顶层Registry。

### Fixed

- 非依赖processing_run_id不再产生dangling error。
- Schema Registry测试改为确定性版本验证。
- 发布过程加入Manifest、SHA-256和collect-only完整性门禁。

### Validated

- Python 3.11.13。
- SQLite 3.26+。
- 84 tests passed。
- 96.34% coverage。
- 非空V1.0数据迁移和恢复通过。
- M1 Exit Review通过。

### Frozen

- Aurora V1.1作为M2的MVP核心对象契约。
